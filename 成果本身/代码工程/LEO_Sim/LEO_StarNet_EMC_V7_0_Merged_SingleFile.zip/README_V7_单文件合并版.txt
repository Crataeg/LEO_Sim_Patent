LEO_StarNet_EMC_V7 单文件合并版说明

运行方式：
1) 默认运行
   result = LEO_StarNet_EMC_V7_0_Engineering_Merged();

2) 打开参数输入界面
   result = LEO_StarNet_EMC_V7_0_Engineering_Merged('ui');

3) 传入配置结构体
   cfg = struct();
   cfg.Downlink = struct('SatEIRP_dBm', 55);
   result = LEO_StarNet_EMC_V7_0_Engineering_Merged(cfg);

说明：
- 本版本为单文件自包含版本，不依赖 emcDefaultConfig 等外部函数。
- 若之前的 V7 工程报错“函数或变量 emcDefaultConfig 无法识别”，请改用本单文件版本。
- 本版本内置默认参数，可不输入任何参数直接运行。
